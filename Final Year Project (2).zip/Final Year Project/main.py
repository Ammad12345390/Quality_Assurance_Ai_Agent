import os
import shutil
import zipfile
from tkinter import Tk, filedialog
from rptree.rptree import DirectoryTree


def extract_zip(zip_path, extract_to="extracted"):
    """
    Extracts the given ZIP file to a clean folder.
    If an old extracted folder exists, it will be deleted first.
    """
    # 🧹 Clean previous extracted folder if it exists
    if os.path.exists(extract_to):
        shutil.rmtree(extract_to)

    os.makedirs(extract_to)

    # 📦 Extract the ZIP file
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)

    print(f"✅ Extracted to: {extract_to}")
    return extract_to


def find_python_entry_files(folder):
    """
    Finds common Python entry files such as main.py or app.py.
    Returns a new list each time.
    """
    entry_candidates = [
        "main.py", "app.py", "run.py", "manage.py", "index.py", "__main__.py"
    ]
    found_entries = []  # ✅ Always fresh for each run

    for root, _, files in os.walk(folder):
        for file in files:
            if file.lower() in entry_candidates:
                full_path = os.path.join(root, file)
                found_entries.append(full_path)

    if found_entries:
        print("\n🚀 Possible Python entry files found:")
        for f in found_entries:
            print(f"   • {f}")
    else:
        print("\n⚠️ No common Python entry file found.")

    return found_entries


def main():
    """
    Main function to extract a ZIP file, show its structure,
    and identify main Python files.
    """
    # 🗂️ Open file picker dialog
    Tk().withdraw()  # Hide the root tkinter window
    zip_path = filedialog.askopenfilename(
        title="Select a Python Project ZIP file",
        filetypes=[("ZIP files", "*.zip")]
    )

    if not zip_path:
        print("❌ No file selected.")
        return

    print(f"📦 Selected file: {zip_path}")

    # 🧳 Extract the selected ZIP file (clean previous one)
    folder = extract_zip(zip_path)

    # 🧩 Show extracted directory structure
    print("\n🧩 Directory Structure:\n")
    tree = DirectoryTree(folder)
    tree.generate()  # Display directory tree in console

    # 🧭 Identify Python entry files
    find_python_entry_files(folder)

    print("\n✅ Analysis complete!\n")


if __name__ == "__main__":
    main()

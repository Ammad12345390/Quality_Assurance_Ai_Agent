# cli.py
import zipfile
import os
from pathlib import Path
from rptree import DirectoryTree
import tkinter as tk
from tkinter import filedialog

def choose_zip_file():
    """Open file picker to select ZIP file."""
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="Select ZIP File",
        filetypes=[("ZIP Files", "*.zip")]
    )
    return file_path

def extract_zip(zip_path, extract_to):
    """Extracts the given ZIP file to the specified directory."""
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
    print(f"✅ ZIP file extracted to: {extract_to}")

def main():
    print("📦 Please select a ZIP file to generate RP Tree...")
    zip_path = choose_zip_file()
    if not zip_path:
        print("❌ No file selected. Exiting.")
        return

    extract_to = Path("extracted_project")
    extract_to.mkdir(exist_ok=True)

    extract_zip(zip_path, extract_to)

    # ✅ Generate and display RP Tree
    tree = DirectoryTree(extract_to)
    tree.generate_tree()

if __name__ == "__main__":
    main()

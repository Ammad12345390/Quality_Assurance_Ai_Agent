import os
import zipfile
from tkinter import Tk, filedialog
from rptree.rptree import DirectoryTree

def extract_zip(zip_path, extract_to="extracted"):
    if not os.path.exists(extract_to):
        os.makedirs(extract_to)
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
    print(f"✅ Extracted to: {extract_to}")
    return extract_to

def main():
    # 🗂️ Open file picker dialog
    Tk().withdraw()  # Hide the root tkinter window
    zip_path = filedialog.askopenfilename(
        title="Select a ZIP file",
        filetypes=[("ZIP files", "*.zip")]
    )

    if not zip_path:
        print("❌ No file selected.")
        return

    print(f"📦 Selected file: {zip_path}")

    folder = extract_zip(zip_path)
    print("\n🧩 Directory Structure:\n")

    tree = DirectoryTree(folder)
    tree.generate()  # Display RT tree in console

if __name__ == "__main__":
    main()

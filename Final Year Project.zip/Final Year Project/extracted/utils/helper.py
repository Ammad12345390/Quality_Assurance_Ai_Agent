def greet():
    print('Hello from helper!')
